package top_up_game;

public interface User {
    String login(String username,String password);
}